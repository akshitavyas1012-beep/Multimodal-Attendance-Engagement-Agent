import streamlit as st
import cv2, time, csv, json, math
import numpy as np
import pandas as pd
from datetime import datetime
from pathlib import Path
from collections import defaultdict
import tempfile

DATA=Path("data")
DATA.mkdir(exist_ok=True)
LOG=DATA/"attendance.csv"

st.set_page_config(page_title="Classroom Intelligence",page_icon="🎓",layout="wide")
st.title("🎓 Multimodal Attendance & Engagement Agent")
st.caption("Offline classroom demo • consent-first • engagement estimates are not grades")

with st.sidebar:
    st.header("Session")
    session_name=st.text_input("Session / subject","DBMS")
    threshold=st.slider("Presence confirmation (seconds)",2,30,8)
    st.info("Use only with informed consent. Prefer a test video or consenting volunteers. This demo detects anonymous faces; it does not identify people.")

tab1,tab2,tab3=st.tabs(["Live / video analysis","Session analytics","Teaching suggestions"])

def record_attendance(session, track_id, seconds):
    now=datetime.now().isoformat(timespec="seconds")
    exists=LOG.exists()
    with LOG.open("a",newline="",encoding="utf-8") as f:
        w=csv.writer(f)
        if not exists: w.writerow(["session","anonymous_track","first_seen","confirmed_after_seconds"])
        w.writerow([session,track_id,now,round(seconds,1)])

with tab1:
    st.subheader("Video analysis")
    mode=st.radio("Input",["Webcam","Upload video"],horizontal=True)
    uploaded=st.file_uploader("Choose an MP4/AVI video",type=["mp4","avi","mov"]) if mode=="Upload video" else None
    run=st.button("Start analysis",type="primary")
    preview=st.empty()
    metrics=st.empty()
    chart=st.empty()
    if run:
        cap=None
        temp=None
        if mode=="Webcam":
            cap=cv2.VideoCapture(0)
        elif uploaded:
            tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".mp4")
            tmp.write(uploaded.read()); tmp.close()
            temp=tmp.name
            cap=cv2.VideoCapture(temp)
        else:
            st.warning("Upload a video first.")
        if cap and cap.isOpened():
            detector=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
            first_seen={}
            confirmed=set()
            active_seconds=[]
            total_frames=0
            start=time.time()
            stop=st.button("Stop")
            st.warning("Analysis is running. Press Stop or wait for the video to finish.")
            while cap.isOpened():
                ok,frame=cap.read()
                if not ok: break
                total_frames+=1
                # Anonymous face detection; no identity recognition or face-image storage.
                gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
                faces=detector.detectMultiScale(gray,scaleFactor=1.15,minNeighbors=5,minSize=(40,40))
                now=time.time()
                for i,(x,y,w,h) in enumerate(faces):
                    # Demo-level association: positions are temporary, anonymous labels.
                    tid=f"Face-{i+1}"
                    first_seen.setdefault(tid,now)
                    elapsed=now-first_seen[tid]
                    color=(30,190,90) if elapsed>=threshold else (20,160,230)
                    cv2.rectangle(frame,(x,y),(x+w,y+h),color,2)
                    cv2.putText(frame,f"{tid} {elapsed:.0f}s",(x,y-8),cv2.FONT_HERSHEY_SIMPLEX,.55,color,2)
                    if elapsed>=threshold and tid not in confirmed:
                        confirmed.add(tid)
                        record_attendance(session_name,tid,elapsed)
                # Movement/activity proxy from frame-to-frame pixel change, not emotion/attention.
                small=cv2.resize(gray,(160,90))
                if "prev" in locals():
                    activity=float(np.mean(cv2.absdiff(small,prev)))
                else: activity=0.0
                prev=small
                active_seconds.append(activity)
                rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
                preview.image(rgb,channels="RGB",use_container_width=True)
                metrics.metric("Anonymous faces currently detected",len(faces))
                if len(active_seconds)>1:
                    chart.line_chart(pd.DataFrame({"Motion / audio-free activity proxy":active_seconds[-120:]}))
                if mode=="Webcam":
                    if st.button("End webcam session",key="endcam"): break
                # Keep uploaded video manageable; webcam loops are interrupted via app rerun.
                if total_frames>1500: break
            cap.release()
            if temp and os.path.exists(temp): os.unlink(temp)
            st.success(f"Finished. Attendance confirmations: {len(confirmed)}. Logs saved locally to {LOG}.")
            st.caption("This prototype uses frame-local labels, not robust multi-person identity tracking. Treat records as reviewable detections, not final attendance.")
        elif cap:
            st.error("Could not open the selected camera/video. Check camera permissions or video format.")

with tab2:
    st.subheader("Attendance and session analytics")
    if LOG.exists():
        df=pd.read_csv(LOG)
        df=df[df["session"]==session_name]
        if not df.empty:
            a,b=st.columns(2)
            a.metric("Confirmed anonymous tracks",df["anonymous_track"].nunique())
            b.metric("Log entries",len(df))
            st.dataframe(df,use_container_width=True)
            st.download_button("Download session CSV",df.to_csv(index=False),file_name="attendance_session.csv",mime="text/csv")
        else: st.info("No attendance records for this session yet.")
    else: st.info("Run an analysis to create local attendance logs.")
    st.markdown("#### Add session-level signals")
    motion=st.slider("Observed movement/activity (rough)",0,100,45)
    audio=st.slider("Audio activity / discussion (rough)",0,100,35)
    inactivity=st.slider("Long inactivity intervals (rough)",0,100,40)
    score=max(0,min(100,int(.4*motion+.35*audio+.25*(100-inactivity))))
    st.metric("Session activity indicator (not an attention score)",f"{score}/100")
    st.caption("Manual indicators are useful for a demonstration; they are not validated psychological measurements.")

with tab3:
    st.subheader("AI-style teaching suggestions (offline rule-based)")
    st.write("These transparent rules work offline and can be reviewed by the instructor.")
    if "score" not in locals(): score=50
    if score<35:
        suggestions=["Consider a short pause or recap.","Try a low-stakes question or pair discussion.","Check whether the pace or audio/visibility is suitable."]
    elif score<65:
        suggestions=["Add a brief interactive checkpoint.","Summarize the key idea before moving on.","Invite questions through an anonymous channel."]
    else:
        suggestions=["Maintain the current pace while checking comprehension.","Use a short application problem to confirm learning.","Avoid interpreting activity as proof of understanding."]
    for s in suggestions: st.markdown(f"- {s}")
    st.caption("Suggestions are assistive only. No automated grading, discipline, or student ranking.")
