# Multimodal Attendance & Engagement Agent — local prototype

## Included
- Streamlit dashboard
- Webcam or recorded-video input
- Anonymous face detection using OpenCV Haar cascades
- Sustained-presence confirmation and local CSV logs
- Motion/activity proxy
- Session-level manual audio/activity inputs
- Offline, transparent teaching-suggestion rules
- CSV export

## Setup (Windows)
1. Install Python 3.10–3.12.
2. Extract this ZIP and open a terminal in the project folder.
3. Create an environment (recommended):
   `python -m venv .venv`
   `.venv\Scripts\activate`
4. Install:
   `pip install -r requirements.txt`
5. Run:
   `streamlit run app.py`
6. Open the local URL Streamlit prints (usually http://localhost:8501).

## Important prototype limits
- No identity recognition: labels are anonymous and only useful for a small demo.
- Face labels are not persistent multi-person tracking. Avoid using this for official attendance.
- Engagement is not directly measurable from faces or motion. The indicator is an activity proxy.
- Audio is currently represented by a manual session-level input; no audio is recorded.
- All processing and logs are local. Delete `data/attendance.csv` to clear records.
- Use consent, provide notice, allow opt-out, and have an instructor review any attendance result.
